from django.apps import AppConfig


class RandomNumbersConfig(AppConfig):
    name = 'random_numbers'
